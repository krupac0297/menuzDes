import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-business',
  templateUrl: './register-business.component.html',
  styleUrls: ['./register-business.component.scss']
})
export class RegisterBusinessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
